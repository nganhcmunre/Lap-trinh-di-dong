package com.example.lab10_11;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private String topicName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Mở màn hình Chào đầu tiên
        showFrg(new M000SplashFrg());
    }

    // Hàm dùng chung để hiển thị Fragment
    private void showFrg(Fragment frg) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, frg, null)
                .addToBackStack(null) // Cho phép ấn nút Back điện thoại để quay lại
                .commit();
    }

    // Chuyển sang màn hình danh sách Chủ đề (M001)
    public void gotoM001Screen() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, new M001TopicFrg(), null)
                .commit();
    }

    // Chuyển sang màn hình danh sách Truyện (M002)
    public void gotoM002Screen(String topicName) {
        this.topicName = topicName;
        M002StoryFrg frg = new M002StoryFrg();
        frg.setTopicName(topicName); // Truyền tên chủ đề sang để biết mà load file txt

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, frg, null)
                .addToBackStack(null)
                .commit();
    }

    // Quay lại màn hình trước
    public void backToM001Screen() {
        onBackPressed();
    }

    // Chuyển sang màn hình Chi tiết đọc truyện (M003)
    public void gotoM003Screen(ArrayList<StoryEntity> listStory, StoryEntity story) {
        M003DetailStoryFrg frg = new M003DetailStoryFrg();
        frg.setData(topicName, listStory, story);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.ln_main, frg, null)
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void onBackPressed() {
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
        } else {
            super.onBackPressed();
        }
    }
}