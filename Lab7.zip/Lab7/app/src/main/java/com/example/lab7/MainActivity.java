package com.example.lab7;   // 🔴 Sửa cho đúng package của project em

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // ===== Bài 1: Custom Button =====
    private Button btnColoredSelector, btnDisabledSelector;
    private Button btnRoundShape, btnShapeGradient, btnSelectorShape;
    private TextView tvEmoji2, tvEmoji3;

    // ===== Bài 2: Custom Toast + Custom Dialog =====
    private Button btnShowToast, btnShowDialog;

    // ===== Bài 3: mở màn RGB/CMY =====
    private Button btnOpenColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);   // layout DrawableExample đã sửa

        // --------- Ánh xạ view Bài 1 ---------
        btnColoredSelector = findViewById(R.id.btnColoredSelector);
        btnDisabledSelector = findViewById(R.id.btnDisabledSelector);
        btnRoundShape = findViewById(R.id.btnRoundShape);
        btnShapeGradient = findViewById(R.id.btnShapeGradient);
        btnSelectorShape = findViewById(R.id.btnSelectorShape);
        tvEmoji2 = findViewById(R.id.tvEmoji2);
        tvEmoji3 = findViewById(R.id.tvEmoji3);

        // Demo click đơn giản cho Bài 1
        btnColoredSelector.setOnClickListener(v ->
                showShortToast("Colored Selector clicked"));

        btnDisabledSelector.setOnClickListener(v ->
                showShortToast("Button disabled nên không click được"));

        btnRoundShape.setOnClickListener(v ->
                showShortToast("Round Shape clicked"));

        btnShapeGradient.setOnClickListener(v ->
                showShortToast("Shape with Gradient clicked"));

        btnSelectorShape.setOnClickListener(v ->
                showShortToast("Selector Shape clicked"));

        tvEmoji2.setOnClickListener(v ->
                showShortToast("Emoji xanh được nhấn"));

        tvEmoji3.setOnClickListener(v ->
                showShortToast("Emoji viền cam được nhấn"));

        // --------- Ánh xạ view Bài 2 ---------
        btnShowToast = findViewById(R.id.btnShowToast);
        btnShowDialog = findViewById(R.id.btnShowDialog);

        // Nút Custom Toast
        btnShowToast.setOnClickListener(v -> showCustomToast());

        // Nút Custom Dialog
        btnShowDialog.setOnClickListener(v -> showCustomDialog());

        // --------- Ánh xạ view Bài 3 ---------
        btnOpenColor = findViewById(R.id.btnOpenColor);

        btnOpenColor.setOnClickListener(v -> {
            Intent i = new Intent(MainActivity.this, ChooseColorActivity.class);
            startActivity(i);
        });
    }

    // Toast ngắn dùng chung
    private void showShortToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    // ===== Bài 2: Custom Toast =====
    private void showCustomToast() {
        LayoutInflater inflater = getLayoutInflater();
        // root là LinearLayout trong custom_toast.xml (id: toast_root)
        View layout = inflater.inflate(R.layout.custom_toast,
                findViewById(R.id.toast_root));

        TextView tvMsg = layout.findViewById(R.id.tvToastMessage);
        tvMsg.setText("Hello from Custom Toast!");

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.setView(layout);
        toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 200);
        toast.show();
    }

    // ===== Bài 2: Custom Dialog =====
    private void showCustomDialog() {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.custom_dialog, null);

        TextView tvTitle = dialogView.findViewById(R.id.tvDialogTitle);
        TextView tvMessage = dialogView.findViewById(R.id.tvDialogMessage);
        Button btnCancel = dialogView.findViewById(R.id.btnDialogCancel);
        Button btnOk = dialogView.findViewById(R.id.btnDialogOk);

        tvTitle.setText("Thoát ứng dụng");
        tvMessage.setText("Bạn có chắc chắn muốn thoát?");

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(false)
                .create();

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnOk.setOnClickListener(v -> {
            dialog.dismiss();
            finish();  // thoát app, giống trong video
        });

        dialog.show();
    }
}
