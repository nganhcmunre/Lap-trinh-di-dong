package com.example.lab7;   // 🔴 sửa đúng package nếu project em khác

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class ChooseColorActivity extends AppCompatActivity {

    private SeekBar seekR, seekG, seekB;
    private TextView tvR, tvG, tvB;
    private LinearLayout viewRGB, viewCMY;

    private int r = 0, g = 0, b = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_color);  // XML Bài 3

        // Ánh xạ view
        seekR = findViewById(R.id.seekR);
        seekG = findViewById(R.id.seekG);
        seekB = findViewById(R.id.seekB);

        tvR = findViewById(R.id.tvR);
        tvG = findViewById(R.id.tvG);
        tvB = findViewById(R.id.tvB);

        viewRGB = findViewById(R.id.viewRGB);
        viewCMY = findViewById(R.id.viewCMY);

        // Listener chung cho 3 SeekBar
        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int id = seekBar.getId();

                if (id == R.id.seekR) {
                    r = progress;
                    tvR.setText("R = " + r);
                } else if (id == R.id.seekG) {
                    g = progress;
                    tvG.setText("G = " + g);
                } else if (id == R.id.seekB) {
                    b = progress;
                    tvB.setText("B = " + b);
                }

                updateColors();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        };

        seekR.setOnSeekBarChangeListener(listener);
        seekG.setOnSeekBarChangeListener(listener);
        seekB.setOnSeekBarChangeListener(listener);

        // cập nhật lần đầu
        updateColors();
    }

    // Cập nhật 2 ô màu RGB & CMY
    private void updateColors() {
        // RGB
        int colorRGB = Color.rgb(r, g, b);
        viewRGB.setBackgroundColor(colorRGB);

        // CMY = màu bù
        int c = 255 - r;
        int m = 255 - g;
        int y = 255 - b;
        int colorCMY = Color.rgb(c, m, y);
        viewCMY.setBackgroundColor(colorCMY);
    }
}
